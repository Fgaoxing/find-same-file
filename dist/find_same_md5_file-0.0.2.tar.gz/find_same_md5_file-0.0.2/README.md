# find-same-file
[中文文档](https://www.yt-blog.top/58785)

Python searches the same file based on md5
## Example
```py
import find_same_md5_find
print(find_same_find.print_same('U:/'))# My U drive letter is U:, so the location is U:/
```
